package codetest;

import java.io.Serializable;

public interface Calculator extends Serializable {
     /**
      * Reads the input
      * @param input
      * @throws InputNotSupportedException
      * @throws IllegalOperationException
      */
     void readInput(String input) throws InputNotSupportedException, IllegalOperationException;

    /**
     * This method is responsible for calculation
      */
     void calculateResult() throws IllegalOperationException;

    /**
     * Returns the current result
      * @return
     */
     Number displayResult();
}
