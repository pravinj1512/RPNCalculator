package codetest;

import java.util.Scanner;

public class CalculatorClient {

    public static void main(String[] args) {
        Calculator calculator = new RPNCalculatorImpl();

            while (true) {
                System.out.print(">");
                Scanner scanner = new Scanner(System.in);
                String input = scanner.next();
                if (input.equals("q")) {
                    break;
                }
                try {
                    calculator.readInput(input);
                    System.out.println(calculator.displayResult());
                } catch (InputNotSupportedException exception) {
                    System.out.println(exception.getMessage());
                } catch (IllegalOperationException e) {
                    e.printStackTrace();
                }
            }
    }
}
