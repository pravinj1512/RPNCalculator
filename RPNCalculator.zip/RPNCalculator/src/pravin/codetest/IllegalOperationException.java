package codetest;

public class IllegalOperationException extends Exception {
    public IllegalOperationException(String s) {
        super(s);
    }
}
