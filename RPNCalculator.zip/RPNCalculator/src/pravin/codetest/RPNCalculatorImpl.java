package codetest;

import java.util.Stack;

public class RPNCalculatorImpl implements Calculator {

    private static final String OPERATOR_REGEX = "[\\+\\-\\*\\/]";
    private static final String NUMERIC_REGEX = "-?\\d+(\\.\\d+)?";

    private Stack<Number> stack;
    private Character currentOperator;
    private Number result;

    public RPNCalculatorImpl() {
        stack = new Stack<>();
    }

    @Override
    public void calculateResult() throws IllegalOperationException {

        if(stack.isEmpty()){
            throw new IllegalOperationException("Operator without operands...");
        }

        if(!stack.isEmpty() && stack.size() > 1) {
            Number second = stack.pop();
            Number first = stack.pop();

            switch (currentOperator) {
                case '+':
                    result =  first.doubleValue() + second.doubleValue();
                    break;
                case '-':
                    result =  first.doubleValue() - second.doubleValue();
                    break;
                case '*':
                    result =  first.doubleValue() * second.doubleValue();
                    break;
                case '/':
                    result =  first.doubleValue() / second.doubleValue();
                    break;
                default:
                    throw new IllegalOperationException("This operator is not supported..");
            }
            if(result != null) {
                stack.push(result);
            }
        }
    }

    @Override
    public Number displayResult() {
        return result;
    }

    @Override
    public void readInput(String input) throws InputNotSupportedException, IllegalOperationException {
        if(numberKeyPressed(input)) {
            result = Double.parseDouble(input);
            stack.push(result);
        } else if(operatorKeyPressed(input)) {
            currentOperator = input.charAt(0);
            calculateResult();
        } else {
            throw new InputNotSupportedException("This type of input is not allowed...");
        }
    }

    private boolean numberKeyPressed(String key) {
        if(key == null || key.length() == 0) {
            return false;
        }
        return key.matches(NUMERIC_REGEX);
    }

    private boolean operatorKeyPressed(String key) throws IllegalOperationException {

        if(key == null || key.length() == 0) {
            return false;
        }
        if(key.length() > 1) {
            throw new IllegalOperationException("This operation is not allowed...");
        }
        return key.matches(OPERATOR_REGEX);
    }

}
