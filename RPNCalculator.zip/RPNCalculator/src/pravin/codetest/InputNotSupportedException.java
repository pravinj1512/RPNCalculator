package codetest;

public class InputNotSupportedException extends Exception {
    public InputNotSupportedException(String s) {
        super(s);
    }
}
