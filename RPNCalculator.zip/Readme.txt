Pre-requisite :
You must have installed JRE 1.8 and above version to execute this project

Execution :
1) Extract the zip file RPNCalculator.zip.
2) You will find RPNCalculator.jar file and folder RPNCalculator which contains source code.
3) RPNCalculator.jar is executable so you can excute it by using the following command.
java -jar <jarfile-path> 

Overview:

1) This calculator helps us to calculate the reverse polish notation expression. 
2) Currenlty only four arithmatic operations (+,-,*,/) are supported here.
3) Here currently the Strategy pattern is used to choose the type of calculator. Though there is only one implementer but we can have multiple
   types of calculator which can be used in client. 
4) We can also use Memento pattern if we would like to do undo and redo type of calculations.	
